#!/usr/bin/env bash
# On a disposable aarch64 ROCK 5B with repository commit 97275d1 deployed,
# restore docs/benchmarks/workload.tar.gz to its recorded store path first.
# Run this script as root from the extracted evidence directory.
# Existing experiment directories are deliberately not overwritten.
set -euo pipefail
base=/var/tmp/shell-tool-combinations
test ! -e "$base"
test ! -e /home/pi/benchmarks/shell-tool-combinations
test ! -e /home/pi/benchmarks/shell-tools-preflight
mkdir "$base"
cp tools/{environment.sh,run.sh} "$base/"
nix build --no-link --print-out-paths \
  github:NixOS/nixpkgs/a32edd7654519351e48e80372a928df336394670#nix-fast-build \
  github:NixOS/nixpkgs/a32edd7654519351e48e80372a928df336394670#nix-eval-jobs \
  github:DeterminateSystems/nix-eval-jobs/6f0af6ca30d730eb7bb19a5dcd9e998a3b96dcea \
  > "$base/tool-paths.txt"
# The adapter pins the resulting executable store paths from this run.
reference='path:/nix/store/l3jb9dnrdmb6n6mbmcqcxkq07yd9802d-drv-run-benchmark-source?dir=examples/rock5b'
nix --extra-experimental-features baked-derivations flake bake "$reference" \
  --dest-dir "$base/baked" > "$base/bake.stdout" 2> "$base/bake.stderr"
printf '0\n' > "$base/bake.exit"
status=0
nix --extra-experimental-features baked-derivations print-dev-env --json \
  --profile "$base/baked-environment" "path:$base/baked" \
  > "$base/baked-env.stdout" 2> "$base/baked-env.stderr" || status=$?
printf '%s\n' "$status" > "$base/baked-env.exit"
status=0
nix --extra-experimental-features baked-derivations develop "path:$base/baked" \
  --command true > "$base/baked-develop.stdout" 2> "$base/baked-develop.stderr" || status=$?
printf '%s\n' "$status" > "$base/baked-develop.exit"
preflight=/home/pi/benchmarks/shell-tools-preflight
install -d -o pi -g pi "$preflight"
runuser -l pi -c "nix print-dev-env --json --profile '$preflight/native-environment' '$reference'" > "$preflight/native.json"
runuser -l pi -c "bash '$base/environment.sh' eval-jobs '$reference' '$preflight/eval-environment'" > "$preflight/eval.json"
runuser -l pi -c "bash '$base/environment.sh' fast-build '$reference' '$preflight/fast-environment'" > "$preflight/fast.json"
cmp "$preflight/native.json" "$preflight/eval.json"
cmp "$preflight/native.json" "$preflight/fast.json"
bash "$base/run.sh"
