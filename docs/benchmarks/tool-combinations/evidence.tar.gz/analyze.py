import json
import statistics
from pathlib import Path

from nix.packages.bench import benchmark as b

base = Path('.scratch/shell-tool-combinations/evidence')
all_samples = []
records = []
for mode in ['native-before', 'eval-jobs', 'fast-build', 'native-after']:
    directory = base / 'benchmarks' / mode
    manifest = b.read_json(directory / 'manifest.json')
    summary = b.read_json(directory / 'summary.json')
    assert manifest['runs'] == 5
    assert summary['complete'] is True and summary['error'] is None
    assert not (directory / 'pending.json').exists()
    samples = []
    for batch, count in [('warmup', 1), ('measured', 5)]:
        joined = b.load_batch(directory, batch, count)
        for sample in joined:
            assert sample['outcome'] == sample['cleanup'] == 'success'
            assert sample['launcher_exit_code'] == 0
            trial = directory / batch / 'trials' / f"{sample['index']:04d}"
            timing = b.timings(b.read_json(trial / 'unit.json'), b.read_json(trial / 'service.json'), sample['unit'])
            for field in b.METRICS:
                assert timing[field] == sample[field]
        samples.extend(joined)
    assert b.summarize(samples) == {key: value for key, value in summary.items() if key not in ('complete', 'error')}
    assert samples == [json.loads(line) for line in (directory / 'samples.jsonl').read_text().splitlines()]
    times = [sample['launcher_s'] for sample in samples if sample['batch'] == 'measured']
    records.append(dict(mode=mode, manifest=manifest, summary=summary, shell_sample_stddev_s=statistics.stdev(times), samples=samples))
    all_samples.extend(samples)
for field in ['runner', 'environment']:
    assert len({sample[field] for sample in all_samples}) == 1, field
for field in ['boot_id', 'current_system', 'reference', 'versions', 'launcher']:
    assert all(record['manifest'][field] == records[0]['manifest'][field] for record in records), field
assert len({sample['invocation_id'] for sample in all_samples}) == 24
preflight = base / 'preflight'
environments = [json.loads((preflight / f'{mode}.json').read_text()) for mode in ['native', 'eval', 'fast']]
assert all(environment == environments[0] for environment in environments)
assert (base / 'tools' / 'bake.exit').read_text().strip() == '0'
assert (base / 'tools' / 'baked-env.exit').read_text().strip() == '1'
assert (base / 'tools' / 'baked-develop.exit').read_text().strip() == '1'
print(json.dumps(dict(
    schema_version=1,
    date_utc='2026-10-12',
    configuration='Determinate Nix 3.23.1 / upstream 2.35.2; unchanged installed host and guest',
    evaluator=dict(flake='github:DeterminateSystems/nix-eval-jobs/6f0af6ca30d730eb7bb19a5dcd9e998a3b96dcea', release_tag='v3.23.1', package_version='3.23.4', nix_revision='1ef903401b3426fbca74a692e158cca82d7c98ab'),
    fast_build=dict(version='2.0.2', nixpkgs_revision='a32edd7654519351e48e80372a928df336394670'),
    protocol=dict(measured_per_batch=5, excluded_warmups_per_batch=1, order=[r['mode'] for r in records], evaluator_workers=1, fast_build_jobs=1),
    semantics=dict(environment_json_equal=True, environment_store_path=all_samples[0]['environment'], guest_runner=all_samples[0]['runner']),
    notes=[
        'Native controls bracket the two adapters on the same boot. Warm host caches and fresh guest disks; no CPU pinning or cache flushing.',
        'Only a temporary owner user-unit ExecStartPre drop-in changes. All paths still use print-dev-env --profile and the same guest/provisioning/launcher.',
        'eval-jobs selects the devShell derivation; print-dev-env consumes its drvPath rather than evaluating the flake again.',
        'fast-build uses the matched Determinate evaluator and explicit Determinate nix/nix-build paths; it additionally builds the ordinary devShell output before print-dev-env. That output is NOT the environment artifact.',
        'The four-way tool matrix is redundant: nix-fast-build already invokes nix-eval-jobs.',
        'No guest-side evaluator step exists to parallelize: the guest consumes the already prepared -env store path.',
        'No statistically significant speedup claim; use worker times to distinguish evaluation overhead from VM boot variability.',
        'Native-after includes a 13.853 s sample with 10.959 s boot wait; retained, not discarded. The two native batches also show worker-time drift.',
        'No production change retained. Runtime drop-in removed after the last control.',
    ],
    bake=dict(status='unsupported-for-shell-entry', bake_exit_code=0, print_dev_env_exit_code=1, develop_exit_code=1, shell_seconds=None, error=(base / 'tools' / 'baked-env.stderr').read_text().strip(), reason='Baking replaces the Bash derivation with builtin:substitute; Determinate 3.23.1 getDerivationEnvironment requires a Bash builder. No valid time-to-shell or baked-tool combinations exist without changing the workflow.'),
    sources=[
        'https://github.com/DeterminateSystems/nix-src/blob/v3.23.1/src/nix/develop.cc',
        'https://github.com/DeterminateSystems/nix-src/blob/v3.23.1/src/nix/flake-bake.md',
        'https://github.com/DeterminateSystems/nix-src/blob/v3.23.1/src/nix/baked-flake.nix',
        'https://github.com/Mic92/nix-fast-build/blob/2.0.2/nix_fast_build/processes.py',
        'https://github.com/Mic92/nix-fast-build/blob/2.0.2/nix_fast_build/workers.py',
        'https://github.com/DeterminateSystems/nix-eval-jobs/tree/6f0af6ca30d730eb7bb19a5dcd9e998a3b96dcea',
    ],
    batches=records,
), indent=2, allow_nan=False))
