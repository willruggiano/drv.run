#!/usr/bin/env bash
# Experiment adapter: one selected devShell; no changes to guest or provisioning.
set -euo pipefail
mode=$1
reference=$2
profile=$3
nix=/run/current-system/sw/bin/nix
nix_build=/run/current-system/sw/bin/nix-build
evaluator=/nix/store/s1pbbzf2xz5wn21890f0ivkw9zjhp2ch-nix-eval-jobs-3.23.4/bin/nix-eval-jobs
fast=/nix/store/3yncc0nzmmf0rf3bnmk2q16ghh57rhs5-nix-fast-build-2.0.2/bin/nix-fast-build
python=/nix/store/3fl7bdkdxk2k4nssy1d1161isbzn6bsr-python3-3.14.7/bin/python3
case "$mode" in
  eval-jobs)
    "$evaluator" --option accept-flake-config false --workers 1 \
      --gc-roots-dir "${profile}.eval-gcroots" \
      --flake "$reference#devShells.aarch64-linux.default" > "${profile}.jobs.jsonl"
    ;;
  fast-build)
    "$fast" --nix "$nix" --nix-build "$nix_build" --nix-eval-jobs "$evaluator" \
      --option accept-flake-config false --eval-workers 1 -j 1 \
      --skip-cached --no-nom --stream-json-lines \
      --flake "$reference#devShells.aarch64-linux.default" > "${profile}.jobs.jsonl"
    ;;
  *) exit 2 ;;
esac
drv=$("$python" - "$mode" "${profile}.jobs.jsonl" <<'PY'
import json, re, sys
from pathlib import Path
mode, filename = sys.argv[1:]
rows = [json.loads(line) for line in Path(filename).read_text().splitlines()]
assert rows and all(not row.get('error') and row.get('success', True) for row in rows), rows
jobs = rows if mode == 'eval-jobs' else [row for row in rows if row['type'] == 'EVAL']
assert len(jobs) == 1, jobs
path = jobs[0]['drvPath']
assert re.fullmatch(r'/nix/store/[a-z0-9]{32}-[^/\s]+\.drv', path), path
print(path)
PY
)
exec "$nix" print-dev-env --option accept-flake-config false --print-build-logs \
  --json --profile "$profile" -- "$drv"
