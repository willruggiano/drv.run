#!/usr/bin/env bash
# Run as root on the disposable ROCK 5B after fetching the pinned tools.
# Only a runtime user-unit drop-in changes; the installed system stays untouched.
set -euo pipefail
base=/var/tmp/shell-tool-combinations
results=/home/pi/benchmarks/shell-tool-combinations
reference='path:/nix/store/l3jb9dnrdmb6n6mbmcqcxkq07yd9802d-drv-run-benchmark-source?dir=examples/rock5b'
python=/nix/store/3fl7bdkdxk2k4nssy1d1161isbzn6bsr-python3-3.14.7/bin/python3
dropin=/run/user/1001/systemd/user/drv.run@.service.d/90-shell-tools.conf
test ! -e "$dropin"
test ! -e "$results"
install -d -o pi -g pi "$results"
owner() { runuser -l pi -c "$1"; }
reload() { owner 'XDG_RUNTIME_DIR=/run/user/1001 systemctl --user daemon-reload'; }
cleanup() { rm -f "$dropin"; reload; }
trap cleanup EXIT
"$python" - "$base" <<'PY'
import re, sys
from pathlib import Path
base = Path(sys.argv[1])
unit = Path('/etc/systemd/user/drv.run@.service').read_text()
paths = re.findall(r'^ExecStartPre=(/nix/store/[^\n]+)$', unit, re.M)
assert len(paths) == 1, paths
source = Path(paths[0]).read_text()
(base / 'original-worker').write_text(source)
bash = source.splitlines()[0].removeprefix('#!')
old = '''nix print-dev-env --option accept-flake-config false --print-build-logs --json \\
    --profile "$STATE_DIRECTORY/environment" -- "$ref" </dev/null >/dev/null &'''
assert source.count(old) == 1
for mode in ['eval-jobs', 'fast-build']:
    replacement = f'{bash} {base}/environment.sh {mode} "$ref" "$STATE_DIRECTORY/environment" </dev/null >/dev/null &'
    path = base / f'worker-{mode}'
    path.write_text(source.replace(old, replacement))
    path.chmod(0o755)
PY
sleep 30
for mode in native-before eval-jobs fast-build native-after; do
  if [[ $mode == native-* ]]; then
    rm -f "$dropin"
  else
    mkdir -p "$(dirname "$dropin")"
    printf '[Service]\nExecStartPre=\nExecStartPre=%s/worker-%s\n' "$base" "$mode" > "$dropin"
  fi
  reload
  owner "XDG_RUNTIME_DIR=/run/user/1001 systemctl --user cat drv.run@.service" > "$base/$mode.unit"
  owner "/run/current-system/sw/bin/bench --reference '$reference' --runs 5 --output '$results/$mode'" > "$base/$mode.summary.log" 2>&1
  sleep 5
done
